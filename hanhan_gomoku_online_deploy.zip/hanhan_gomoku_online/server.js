const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true }, pingInterval: 25000, pingTimeout: 20000 });
const PORT = process.env.PORT || 3000;
app.use(express.static(path.join(__dirname, 'public')));
app.get('/health', (_, res) => res.json({ ok: true, service: 'hanhan-gomoku' }));

const users = new Map();        // socket.id -> {name, friends:Set}
const nameToSocket = new Map(); // lowercase name -> socket.id
const rooms = new Map();

function cleanName(v) { return String(v || '').trim().slice(0, 12); }
function roomPlayers(room) {
  return [...room.players.entries()].map(([id, p]) => ({ id, name: p.name, color: p.color }));
}
function emitRoomUpdate(code) {
  const room = rooms.get(code); if (!room) return;
  io.to(code).emit('room-update', { code, players: roomPlayers(room) });
}
function freshGrid() { return Array.from({ length: 15 }, () => Array(15).fill('')); }
function checkWin(grid, x, y, color) {
  for (const [dx,dy] of [[1,0],[0,1],[1,1],[1,-1]]) {
    let n=1;
    for (const d of [-1,1]) {
      let xx=x+d*dx, yy=y+d*dy;
      while (xx>=0&&xx<15&&yy>=0&&yy<15&&grid[yy][xx]===color) { n++; xx+=d*dx; yy+=d*dy; }
    }
    if (n>=5) return true;
  }
  return false;
}
function getRoom(socket, code) {
  const room = rooms.get(String(code || '').toUpperCase());
  if (!room || !room.players.has(socket.id)) { socket.emit('room-error', { message: '房间不存在，或你不在该房间内。' }); return null; }
  return room;
}
io.on('connection', socket => {
  socket.on('register', ({ name } = {}) => {
    name = cleanName(name);
    if (!name) return socket.emit('register-error', { message: '昵称不能为空。' });
    const key = name.toLocaleLowerCase();
    const existing = nameToSocket.get(key);
    if (existing && existing !== socket.id && users.has(existing)) {
      return socket.emit('register-error', { message: '这个昵称当前已被在线玩家使用，请换一个昵称。' });
    }
    const old = users.get(socket.id);
    if (old && old.name.toLocaleLowerCase() !== key) nameToSocket.delete(old.name.toLocaleLowerCase());
    users.set(socket.id, { name, friends: old ? old.friends : new Set() });
    nameToSocket.set(key, socket.id);
    socket.emit('registered', { ok: true, name });
  });
  socket.on('create-room', () => {
    const user = users.get(socket.id);
    if (!user) return socket.emit('room-error', { message: '请先设置昵称并连接服务器。' });
    let code; do { code = Math.random().toString(36).slice(2,8).toUpperCase(); } while (rooms.has(code));
    const room = { code, host: socket.id, players: new Map(), grid: freshGrid(), turn: 'black', moves: [], used: { black:0, white:0 }, started:false };
    room.players.set(socket.id, { name:user.name, color:'black' }); rooms.set(code,room); socket.join(code);
    socket.emit('room-created', { code, role:'black' }); emitRoomUpdate(code);
  });
  socket.on('join-room', ({ code } = {}) => {
    code = String(code || '').trim().toUpperCase(); const room = rooms.get(code); const user = users.get(socket.id);
    if (!user) return socket.emit('room-error',{message:'请先设置昵称。'});
    if (!room) return socket.emit('room-error',{message:'房间码无效或房间已关闭。'});
    if (room.players.has(socket.id)) return socket.emit('room-joined',{code,role:room.players.get(socket.id).color});
    if (room.players.size >= 2) return socket.emit('room-error',{message:'房间已满。'});
    const color = [...room.players.values()].some(p=>p.color==='black')?'white':'black';
    room.players.set(socket.id,{name:user.name,color}); socket.join(code);
    socket.emit('room-joined',{code,role:color}); emitRoomUpdate(code);
  });
  socket.on('start-game', ({code}={}) => {
    const room=getRoom(socket,code); if(!room)return;
    if(room.host!==socket.id)return socket.emit('room-error',{message:'只有房主可以开始游戏。'});
    if(room.players.size!==2)return socket.emit('room-error',{message:'请等待一位好友加入房间。'});
    const colors=['black','white'].sort(()=>Math.random()-.5);
    const entries=[...room.players.entries()];
    entries.forEach(([id,p],i)=>p.color=colors[i]);
    room.grid=freshGrid();room.turn='black';room.moves=[];room.used={black:0,white:0};room.started=true;
    entries.forEach(([id,p])=>io.to(id).emit('game-start',{code,color:p.color,players:{black:entries.find(e=>e[1].color==='black')[1].name,white:entries.find(e=>e[1].color==='white')[1].name}}));
    emitRoomUpdate(code);
  });
  socket.on('make-move', ({code,x,y,color}={}) => {
    const room=getRoom(socket,code); if(!room||!room.started)return;
    const p=room.players.get(socket.id); x=Number(x);y=Number(y);
    if(!p||p.color!==color||room.turn!==color||!Number.isInteger(x)||!Number.isInteger(y)||x<0||x>14||y<0||y>14||room.grid[y][x])return;
    room.grid[y][x]=color;room.moves.push({x,y,color,by:socket.id});room.turn=color==='black'?'white':'black';
    io.to(code).emit('move-made',{x,y,color,by:socket.id,turn:room.turn});
    if(checkWin(room.grid,x,y,color)){room.started=false;io.to(code).emit('game-over',{winner:socket.id,message:p.name+' 连成五子，获得胜利！'});}
    else if(room.moves.length===225){room.started=false;io.to(code).emit('game-over',{winner:null,message:'平局，再来一把！'});}
  });
  socket.on('claim-win', ({code,color}={}) => { const room=getRoom(socket,code);if(!room)return; });
  socket.on('undo-request', ({code}={}) => {
    const room=getRoom(socket,code);if(!room||!room.started)return;
    const p=room.players.get(socket.id);if(room.used[p.color]>=2)return socket.emit('undo-result',{ok:false,message:'你的两次悔棋机会已用完。'});
    const other=[...room.players.keys()].find(id=>id!==socket.id);
    if(!other)return;
    room.pendingUndo={requester:socket.id,color:p.color};
    io.to(other).emit('undo-request',{name:p.name});
  });
  socket.on('undo-response', ({code,accept}={}) => {
    const room=getRoom(socket,code);if(!room||!room.pendingUndo)return;
    const req=room.pendingUndo;room.pendingUndo=null;
    if(!accept)return io.to(req.requester).emit('undo-result',{ok:false,message:'好友拒绝了悔棋请求。'});
    const p=room.players.get(req.requester);if(!p||room.used[p.color]>=2||!room.moves.length)return;
    // Undo the last move, plus one more if the requester is playing against the other player.
    // Roll back to the state before the requester's most recent move,
    // including any later opponent move, so the requester can replay that turn.
    let removed = false;
    while (room.moves.length) {
      const last = room.moves.pop();
      room.grid[last.y][last.x] = '';
      if (last.by === req.requester) { removed = true; break; }
    }
    if (!removed) return io.to(req.requester).emit('undo-result',{ok:false,message:'你还没有落子，暂时不能悔棋。'});
    room.used[p.color]++;
    room.turn = p.color;
    io.to(code).emit('undo-result',{ok:true,grid:room.grid,turn:room.turn,used:room.used});
  });
  socket.on('surrender', ({code}={}) => { const room=getRoom(socket,code);if(!room)return;socket.emit('surrender-notice',{}); });
  socket.on('friend-request', ({to}={}) => {
    const from=users.get(socket.id), targetId=nameToSocket.get(cleanName(to).toLocaleLowerCase());
    if(!from)return;
    if(!targetId||!users.has(targetId))return socket.emit('room-error',{message:'对方当前不在线，暂时无法发送申请。'});
    if(targetId===socket.id)return;
    io.to(targetId).emit('friend-request',{from:from.name});
    socket.emit('friend-request-sent',{to});
  });
  socket.on('friend-accept', ({from}={}) => {
    const user=users.get(socket.id), fromId=nameToSocket.get(cleanName(from).toLocaleLowerCase());
    if(!user||!fromId||!users.has(fromId))return socket.emit('room-error',{message:'申请人已离线。'});
    user.friends.add(from);users.get(fromId).friends.add(user.name);
    socket.emit('friend-accepted',{name:from});
    io.to(fromId).emit('friend-accepted',{name:user.name});
  });
  socket.on('get-friends', () => { const user=users.get(socket.id);socket.emit('friend-list',{friends:user?[...user.friends]:[]}); });
  socket.on('friend-invite', ({to}={}) => {
    const user=users.get(socket.id), targetId=nameToSocket.get(cleanName(to).toLocaleLowerCase());
    if(!user||!targetId)return socket.emit('room-error',{message:'好友当前不在线。'});
    io.to(targetId).emit('friend-invite',{from:user.name});
  });
  socket.on('friend-invite-accept', ({from}={}) => {
    const fromId=nameToSocket.get(cleanName(from).toLocaleLowerCase()), user=users.get(socket.id);
    if(fromId&&user)io.to(fromId).emit('friend-invite-accepted',{name:user.name});
  });
  socket.on('disconnect', () => {
    const user=users.get(socket.id);
    if(user){nameToSocket.delete(user.name.toLocaleLowerCase());users.delete(socket.id);}
    for(const [code,room] of rooms){if(room.players.has(socket.id)){room.players.delete(socket.id);io.to(code).emit('opponent-left',{name:user?.name||'好友'});emitRoomUpdate(code);if(room.players.size===0)rooms.delete(code);else room.started=false;}}
  });
});
server.listen(PORT,()=>console.log(`Hanhan Gomoku listening on ${PORT}`));
