# 涵涵五子棋：在线联机部署包

## 已包含
- `public/index.html`：网页游戏，保留两张用户提供的棋子照片。
- `server.js`：Express + Socket.IO 实时房间、昵称在线冲突校验、落子同步、悔棋请求确认、在线好友申请基础逻辑。
- `package.json`：Node.js 依赖和启动脚本。

## 一键部署建议：Render
1. 把整个文件夹上传到一个新的 GitHub 仓库。
2. 登录 Render，选择 **New + → Web Service**，连接这个仓库。
3. Runtime 选择 Node；Build Command 填 `npm install`；Start Command 填 `npm start`。
4. 部署完成后，Render 会提供 `https://你的服务名.onrender.com` 网址。
5. 用该网址打开网页测试；不要直接双击本地 `index.html`，因为实时通信必须经过服务器。

## 本地运行
需要安装 Node.js 18 或更高版本。在项目目录运行：
```bash
npm install
npm start
```
然后打开 `http://localhost:3000`。

## 重要说明
- 这是可部署的联机原型，不是已经上线的公网网址。必须由你或有权限的人在云平台完成部署。
- 当前在线昵称冲突校验仅针对同时在线的昵称；永久唯一账号、好友数据持久化、离线好友申请、登录鉴权和防作弊仍需数据库与账号系统。
- 为避免误导，当前好友申请基础逻辑仅对在线玩家有效；真正上线前建议补充数据库、用户认证、限流与更严格的服务器端规则验证。
- 本项目没有内置云平台密钥，也不会自动创建你的云服务。
